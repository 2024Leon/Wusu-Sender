<?php
$apiKey = 're_W9gDRvwU_HrHdqGzKKrvAUkG4wy4tca8y'; // Use your actual Resend API key
$from = 'Acme <onboarding@resend.dev>'; // Sender identity configured in Resend

$emails = $_POST['emails'] ?? [];
$subject = $_POST['subject'] ?? '';
$body = $_POST['body'] ?? '';

if (empty($emails) || empty($subject) || empty($body)) {
    exit("Missing required input.");
}

// Build batch email payload
$batch = array_map(function($email) use ($from, $subject, $body) {
    return [
        'from' => $from,
        'to' => [$email],
        'subject' => $subject,
        'html' => $body
    ];
}, $emails);

// Send to Resend batch API
$ch = curl_init('https://api.resend.com/emails/batch');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $apiKey,
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($batch));

$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

// Output
echo "<h2>Response from Resend:</h2>";
if ($error) {
    echo "<p style='color: red;'>cURL Error: $error</p>";
} else {
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}
?>
