<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bulk Email Sender</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; max-width: 600px; margin: auto; }
    .email-group { margin-bottom: 1rem; }
    .email-group input { margin-right: 1rem; width: 100%; padding: 0.5rem; }
    textarea, input[type="text"] { width: 100%; padding: 0.5rem; margin-bottom: 1rem; }
    button { padding: 0.5rem 1rem; }
  </style>
</head>
<body>
  <h1>Send Bulk Emails via Resend</h1>
  <form method="post" action="send.php">
    <div id="email-list">
      <div class="email-group">
        <input type="email" name="emails[]" placeholder="Recipient Email" required>
      </div>
    </div>
    <button type="button" onclick="addEmailField()">+ Add another recipient</button>

    <h3>Subject</h3>
    <input type="text" name="subject" placeholder="Subject" required>

    <h3>HTML Body</h3>
    <textarea name="body" placeholder="<h1>Hello</h1><p>Welcome to our newsletter...</p>" rows="10" required></textarea>

    <button type="submit">Send Emails</button>
  </form>

  <script>
    function addEmailField() {
      const div = document.createElement('div');
      div.className = 'email-group';
      div.innerHTML = '<input type="email" name="emails[]" placeholder="Recipient Email" required>';
      document.getElementById('email-list').appendChild(div);
    }
  </script>
</body>
</html>
